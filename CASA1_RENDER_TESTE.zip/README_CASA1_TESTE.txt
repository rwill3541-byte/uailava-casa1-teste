UAI LAVA - RENDER SEPARADO - TESTE CASA 1
==========================================

Objetivo
--------
Servico independente somente para a Midea "casa 1".
Nao tem monitor em background, nao controla ESP e nao altera o Render principal.
So faz login na SmartHome quando voce abre /status ou /aplicar.

Casa 1
------
Device ID padrao: 151732605699850

Teste atual
-----------
A maquina usa dehydration_time_value=10 e, na observacao pratica, a centrifugacao
comeca perto de 12 minutos restantes.
Este servico define dehydration_time=13 para testar se a centrifugacao passa a
comecar perto de 15 minutos restantes.

IMPORTANTE: 13 -> ~15 min restantes e uma calibracao experimental. Confirme em
um ciclo real antes de aplicar em qualquer outra maquina.

Arquivos no repositorio novo
----------------------------
1. Renomeie app_casa1_teste.py para app.py
2. Renomeie requirements_casa1_teste.txt para requirements.txt

Render - novo Web Service
-------------------------
Build Command:
  pip install -r requirements.txt

Start Command:
  gunicorn app:app

Variaveis de ambiente
---------------------
Preferido (conta SmartHome separada, com Casa 1 compartilhada):
  MIDEA_ACCOUNT_TESTE=<email>
  MIDEA_PASSWORD_TESTE=<senha>

Opcionais:
  MIDEA_CLOUD=SmartHome
  CASA1_DEVICE_ID=151732605699850
  CASA1_DEHYDRATION_TIME=13
  TESTE_TOKEN=<um token que voce escolher>

Se MIDEA_ACCOUNT_TESTE / MIDEA_PASSWORD_TESTE nao existirem, o app aceita
MIDEA_ACCOUNT / MIDEA_PASSWORD como fallback.

ROTAS
-----
/
  Pagina simples com os botoes.

/health
  Nao faz login na Midea. So confirma que o servico esta vivo.

/status
  Faz uma leitura sob demanda da Casa 1.

/aplicar?confirmar=SIM
  So aplica se:
  - Casa 1 estiver ligada;
  - estiver parada;
  - programa Favorito (254) estiver selecionado.

O comando altera SOMENTE dehydration_time. Nao envia START, nao muda POWER,
programa, temperatura, nivel de agua, tempo de lavagem ou RPM.

Se usar TESTE_TOKEN, adicione ?token=SEU_TOKEN nas URLs.

RECOMENDACAO
------------
Use uma segunda conta SmartHome com apenas a Casa 1 compartilhada. Isso reduz
o risco de uma sessao manual deste servico competir com a sessao do Render
principal que monitora as lojas.
